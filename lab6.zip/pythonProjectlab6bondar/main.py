import qrcode

def create_qr(data, filename="qr_code.png"):
    """
    Створює QR-код з переданими даними.

    Аргументи:
        data (str): Дані для кодування у QR-коді.
        filename (str): Ім'я файлу для збереження QR-коду.

    Повертає:
        PIL.Image.Image: Зображення QR-коду.
    """
    # Генеруємо QR-код
    qr = qrcode.QRCode(
        version=1,  # Версія 1 відповідає 21x21 пікселів
        error_correction=qrcode.constants.ERROR_CORRECT_L,  # Мінімальна корекція помилок
        box_size=10,  # Розмір кожного квадратика
        border=4,  # Розмір рамки
    )
    qr.add_data(data)
    qr.make(fit=True)

    # Створюємо зображення
    img = qr.make_image(fill="black", back_color="white")

    # Зберігаємо зображення
    img.save(filename)
    print(f"QR-код збережено як {filename}")

    return img

# Основна частина програми
if __name__ == "__main__":
    print("Виберіть тип даних для QR-коду:")
    print("1. Текст")
    print("2. Посилання")
    print("3. Контактна інформація")

    choice = input("Ваш вибір (1/2/3): ")

    if choice == "1":
        data = input("Введіть текст для QR-коду: ")
    elif choice == "2":
        data = input("Введіть посилання для QR-коду: ")
    elif choice == "3":
        name = input("Введіть ім'я: ")
        phone = input("Введіть номер телефону: ")
        email = input("Введіть email: ")
        data = f"BEGIN:VCARD\nVERSION:3.0\nFN:{name}\nTEL:{phone}\nEMAIL:{email}\nEND:VCARD"
    else:
        print("Невірний вибір! Завершення програми.")
        exit()

    # Генеруємо QR-код
    qr_image = create_qr(data, "user_qr.png")

    # Відкриваємо QR-код у переглядачі
    qr_image.show()

    print("Ваш QR-код відкрито у переглядачі та збережено у файл 'user_qr.png'!")
